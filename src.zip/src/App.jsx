import { useState } from 'react'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import KpiCard from './components/KpiCard'
import RevenueChart from './components/RevenueChart'
import PlanDonut from './components/PlanDonut'
import UsersTable from './components/UsersTable'
import ActivityFeed from './components/ActivityFeed'
import { kpiData } from './data'

export default function App() {
  const [activeNav, setActiveNav] = useState('Dashboard')

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar activeNav={activeNav} setActiveNav={setActiveNav} />
      <main className="flex-1 overflow-y-auto px-8 py-7">
        <Topbar activeNav={activeNav} />
        <div className="grid grid-cols-4 gap-4 mb-5">
          {kpiData.map((kpi, i) => (
            <KpiCard key={kpi.id} {...kpi} delay={`delay-${i + 1}`} />
          ))}
        </div>
        <div className="grid grid-cols-[1.65fr_1fr] gap-4 mb-5">
          <RevenueChart />
          <PlanDonut />
        </div>
        <div className="grid grid-cols-[1.4fr_1fr] gap-4">
          <UsersTable />
          <ActivityFeed />
        </div>
      </main>
    </div>
  )
}
